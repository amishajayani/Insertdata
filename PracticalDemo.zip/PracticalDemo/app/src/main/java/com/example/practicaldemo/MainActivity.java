package com.example.practicaldemo;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ParentAdapter parentAdapter;
    private List<ParentItem> parentItemList;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);
        parentItemList = new ArrayList<>();

        // Fetch data from the database and set up RecyclerView
        List<ChildItem> childItems = databaseHelper.getAllItems();
        parentItemList.add(new ParentItem("Group 1", childItems)); // Example grouping
        parentAdapter = new ParentAdapter(parentItemList);
        recyclerView.setAdapter(parentAdapter);

        findViewById(R.id.btn_add).setOnClickListener(v -> showAddDialog());
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        EditText etName = dialogView.findViewById(R.id.et_name);
        Spinner spinnerRole = dialogView.findViewById(R.id.spinner_role);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = etName.getText().toString().trim();
            String role = spinnerRole.getSelectedItem().toString();

            if (!name.isEmpty()) {
                // Insert data into database
                databaseHelper.insertItem(name, role);

                // Refresh data
                List<ChildItem> updatedChildItems = databaseHelper.getAllItems();
                parentItemList.get(0).getChildItems().clear();
                parentItemList.get(0).getChildItems().addAll(updatedChildItems);
                parentAdapter.notifyDataSetChanged();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.create().show();
    }
}
