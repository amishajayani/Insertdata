package com.example.practicaldemo;

public class ChildItem {
    private String name;
    private String role;

    public ChildItem(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public String getRole() {
        return role;
    }
}
