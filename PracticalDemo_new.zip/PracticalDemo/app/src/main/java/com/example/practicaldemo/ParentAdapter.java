package com.example.practicaldemo;

import android.animation.ObjectAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.practicaldemo.ChildAdapter;
import com.example.practicaldemo.ParentItem;
import com.example.practicaldemo.R;

import java.util.List;

public class ParentAdapter extends RecyclerView.Adapter<ParentAdapter.ParentViewHolder> {
    private List<ParentItem> parentItemList;

    public ParentAdapter(List<ParentItem> parentItemList) {
        this.parentItemList = parentItemList;
    }

    @NonNull
    @Override
    public ParentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.parent_item, parent, false);
        return new ParentViewHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull ParentViewHolder holder, int position) {
        ParentItem parentItem = parentItemList.get(position);

        // Set the parent title
        holder.tvParentTitle.setText(parentItem.getTitle());

        // Show or hide the child RecyclerView based on the expansion state
        if (parentItem.isExpanded()) {
            holder.recyclerView.setVisibility(View.VISIBLE);
            ObjectAnimator.ofFloat(holder.recyclerView, "alpha", 0f, 1f).setDuration(300).start();
            ChildAdapter childAdapter = new ChildAdapter(parentItem.getChildItems());
            holder.recyclerView.setLayoutManager(new LinearLayoutManager(holder.recyclerView.getContext()));
            holder.recyclerView.setAdapter(childAdapter);
        } else {
            holder.recyclerView.setVisibility(View.GONE);
        }

        // Toggle the expansion state when the parent item is clicked
        holder.itemView.setOnClickListener(v -> {
            parentItem.setExpanded(!parentItem.isExpanded());
            notifyItemChanged(position); // Update the specific item
        });
    }


    @Override
    public int getItemCount() {
        return parentItemList.size();
    }

    public static class ParentViewHolder extends RecyclerView.ViewHolder {
        TextView tvParentTitle;
        RecyclerView recyclerView;

        public ParentViewHolder(@NonNull View itemView) {
            super(itemView);
            tvParentTitle = itemView.findViewById(R.id.tv_parent_title);
            recyclerView = itemView.findViewById(R.id.recycler_view); // Ensure this matches the ID in item_parent.xml
        }
    }
}
